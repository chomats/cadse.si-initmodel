/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package fede.workspace.tool.loadmodel.internal.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;

import fede.workspace.role.initmodel.ErrorWhenLoadedModel;
import fede.workspace.tool.loadmodel.model.jaxb.CCadse;
import fede.workspace.tool.loadmodel.model.jaxb.CItemType;
import fr.imag.adele.cadse.core.CompactUUID;
import fr.imag.adele.cadse.core.internal.Nullable;
import fr.imag.adele.fede.workspace.si.initmodel.InitModel;
import fr.imag.adele.melusine.as.findmodel.ModelEntry;

/**
 * This class represents a workspace model, comprising itemtypes and
 * workspacetype.
 * 
 * This particular implementation stores itemtype definition in an independent
 * XML document named types.xml and each workspacetypes in a separted file, in
 * the specified model directory.
 * 
 * @author Stephane Chomat
 * @version 1
 * @date 23/09/05
 */
public class ModelRepository implements FilenameFilter {

	/** The Constant FILE_NAME. */
	static public final String			FILE_NAME			= "cadse.xml";

	/** The Constant QUALIFIED_FILE_NAME. */
	static public final String			QUALIFIED_FILE_NAME	= "model/cadse.xml";

	/** The Constant METADATA. */
	private final static String			METADATA			= "definition.xml";

	/** The Constant SUFFIX. */
	private final static String			SUFFIX				= ".xml";

	/** The Constant TYPES_NAME_FILE. */
	private final static String			TYPES_NAME_FILE		= "types.xml";

	// private CItemType loadedWt = null;
	/** The type map. */
	private Map<CompactUUID, CItemType>	typeMap;

	/** The model. */
	private ModelEntry					model;

	/** The cadse. */
	private CCadse						cadse;

	/**
	 * The Constructor.
	 * 
	 * @param model
	 *            the model
	 * 
	 * @exception IllegalArgumentException(Workspace
	 *                Model not found)
	 * @exception IllegalArgumentException(Workspace
	 *                has more one model)
	 */
	public ModelRepository(ModelEntry model) {
		this.model = model;
	}

	/**
	 * Instantiates a new model repository.
	 */
	public ModelRepository() {
		model = null;
	}

	/**
	 * Find model file.
	 * 
	 * @param initModel
	 * 
	 * @param qualifiedModelName
	 *            the qualified model name
	 * 
	 * @return the model repository
	 */
	public static ModelRepository findModelFile(InitModel initModel, String qualifiedModelName) {
		ModelEntry models = initModel.getFindModelService().findQualifiedModel("Workspace", qualifiedModelName);
		if (models == null) {
			return null;
		}
		return new ModelRepository(models);
	}

	/**
	 * Find model file.
	 * 
	 * @param initModel
	 * 
	 * @param qualifiedModelName
	 *            the qualified model name
	 * 
	 * @return the model repository
	 */
	public static ModelEntry[] findModelFile(InitModel initModel) {
		ModelEntry[] models = initModel.getFindModelService().findModelEntries("Workspace");
		if (models == null) {
			return null;
		}
		return models;
	}

	/**
	 * Gets the types.
	 * 
	 * @return the unmodifiable map of the type
	 */
	public Map<CompactUUID, CItemType> getTypes() {
		return Collections.unmodifiableMap(typeMap);
	}

	/**
	 * Gets the type.
	 * 
	 * @param typeName
	 *            the name of the type to return
	 * 
	 * @return return the type which name is typeName.
	 */
	public CItemType getType(String typeName) {
		return typeMap.get(typeName.toUpperCase());
	}

	/**
	 * Read.
	 * 
	 * @param initModel
	 *            the init model
	 * @param s
	 *            the s
	 * 
	 * @throws JAXBException
	 *             the JAXB exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void read(InitModel initModel, InputStream s) throws JAXBException, IOException {
		typeMap = new HashMap<CompactUUID, CItemType>();
		cadse = initModel.read(s);
		List<CItemType> types = cadse.getItemType();
		for (CItemType it : types) {
			typeMap.put(initModel.getUUID(it.getId()), it);
		}

	}

	/**
	 * remove un type dans la map courrante des type.
	 * 
	 * @param type
	 *            la definition d'un item type, peut �tre null.
	 */
	public void removeType(@Nullable
	CItemType type) {
		if (type != null) {
			typeMap.remove(type.getName().toUpperCase());
		}
	}

	/**
	 * Accept.
	 * 
	 * @param dir
	 *            the dir
	 * @param name
	 *            the name
	 * 
	 * @return true, if accept
	 * 
	 * @see java.io.FilenameFilter#accept(java.io.File, java.lang.String)
	 */
	public boolean accept(@SuppressWarnings("unused")
	File dir, String name) {
		return name.endsWith(SUFFIX) && !name.equalsIgnoreCase(METADATA) && !name.equalsIgnoreCase(TYPES_NAME_FILE);
	}

	/**
	 * Load workspace type.
	 * 
	 * @param initModel
	 *            the init model
	 * 
	 * @throws ErrorWhenLoadedModel
	 *             the error when loaded model
	 */
	public CCadse loadWorkspaceType(InitModel initModel) throws ErrorWhenLoadedModel {
		try {
			URL models = model.getEntry(QUALIFIED_FILE_NAME);
			if (models == null) {
				throw new ErrorWhenLoadedModel("Cant find the entry " + QUALIFIED_FILE_NAME + " in " + model.getName());
			}

			read(initModel, models.openStream());
		} catch (FileNotFoundException e) {
			throw new ErrorWhenLoadedModel("Can't read the workspace type in the model " + model.getName(), e);
		} catch (IOException e) {
			throw new ErrorWhenLoadedModel("Can't read the workspace type in the model " + model.getName(), e);
		} catch (JAXBException e) {
			throw new ErrorWhenLoadedModel("Can't read the workspace type in the model " + model.getName(), e);
		}
		return cadse;

	}

	// return a copy modifiable
	/**
	 * Gets the item type.
	 * 
	 * @return the item type
	 */
	public Map<CompactUUID, CItemType> getItemType() {
		return new HashMap<CompactUUID, CItemType>(this.typeMap);
	}

	/**
	 * Gets the cadse.
	 * 
	 * @return the cadse
	 * @throws IOException
	 * @throws ErrorWhenLoadedModel
	 */
	public CCadse getCadse() {
		return cadse;
	}

	/**
	 * Gets the cadse.
	 * 
	 * @return the cadse
	 * @throws IOException
	 * @throws ErrorWhenLoadedModel
	 * @throws JAXBException
	 */
	public CCadse load(InitModel initModel) throws ErrorWhenLoadedModel {
		if (cadse == null) {
			try {
				URL models = model.getEntry(QUALIFIED_FILE_NAME);
				if (models == null) {
					throw new ErrorWhenLoadedModel("Cant find the entry " + QUALIFIED_FILE_NAME + " in "
							+ model.getName());
				}
				cadse = initModel.read(models.openStream());
			} catch (FileNotFoundException e) {
				throw new ErrorWhenLoadedModel("Can't read the workspace type in the model " + model.getName(), e);
			} catch (IOException e) {
				throw new ErrorWhenLoadedModel("Can't read the workspace type in the model " + model.getName(), e);
			} catch (JAXBException e) {
				throw new ErrorWhenLoadedModel("Can't read the workspace type in the model " + model.getName(), e);
			}
		}
		return cadse;
	}

}
